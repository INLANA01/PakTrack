#PakTrack Standalone Client

##Libraries 
* Prism Library from Microsoft Best Practices and Pattern - https://github.com/PrismLibrary/Prism
* MahMetro for user interface - http://mahapps.com/

##UI Structure (MVVM)
The UI project is organized following the feature based approach, Basically we will have vies and viewmodel for a given area in the same folder.