﻿namespace PakTrack.DTO
{
    public class HumidityDTO: BaseDTO
    {
        public double Value { get; set; }
    }
}