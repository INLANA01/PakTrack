﻿using System.Windows.Controls;

namespace PakTrack.UI.Setting
{
    /// <summary>
    /// Interaction logic for Setting
    /// </summary>
    public partial class Setting : UserControl
    {
        public Setting()
        {
            InitializeComponent();
        }
    }
}
