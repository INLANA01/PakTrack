﻿namespace PakTrack.UI.Utilities
{
    public class StatusInformation
    {
        public string Action { get; set; }
        public string Status { get; set; }
        public bool IsCompleted { get; set; }
    }
}