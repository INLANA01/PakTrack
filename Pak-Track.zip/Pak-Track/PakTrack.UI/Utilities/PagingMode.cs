﻿namespace PakTrack.UI.Utilities
{
    public enum PagingMode
    {
        First,
        Next,
        Previous,
        Last,
        PageCountChange
    };
}