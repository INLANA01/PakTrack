﻿using System.Windows.Controls;

namespace PakTrack.UI.HumidityArea
{
    /// <summary>
    /// Interaction logic for HumidityView
    /// </summary>
    public partial class HumidityView : UserControl
    {
        public HumidityView()
        {
            InitializeComponent();
        }
    }
}
