﻿using System.Windows.Controls;

namespace PakTrack.UI.TemperatureArea
{
    /// <summary>
    /// Interaction logic for TemperatureView
    /// </summary>
    public partial class TemperatureView : UserControl
    {
        public TemperatureView()
        {
            InitializeComponent();
        }
    }
}
