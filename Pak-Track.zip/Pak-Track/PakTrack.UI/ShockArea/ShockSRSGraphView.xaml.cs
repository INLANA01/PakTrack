﻿using System.Windows.Controls;

namespace PakTrack.UI.ShockArea
{
    /// <summary>
    /// Interaction logic for ShockSRSGraphView
    /// </summary>
    public partial class ShockSRSGraphView : UserControl
    {
        public ShockSRSGraphView()
        {
            InitializeComponent();
        }
    }
}
