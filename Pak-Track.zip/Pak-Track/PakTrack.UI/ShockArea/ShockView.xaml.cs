﻿using System.Windows.Controls;

namespace PakTrack.UI.ShockArea
{
    /// <summary>
    /// Interaction logic for ShockView
    /// </summary>
    public partial class ShockView : UserControl
    {
        public ShockView()
        {
            InitializeComponent();
        }
    }
}
