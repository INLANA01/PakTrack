﻿using System.Windows.Controls;

namespace PakTrack.UI.ShockArea
{
    /// <summary>
    /// Interaction logic for ShockTimeGraphView
    /// </summary>
    public partial class ShockTimeGraphView : UserControl
    {
        public ShockTimeGraphView()
        {
            InitializeComponent();
        }
    }
}
