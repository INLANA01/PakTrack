﻿using System.Windows.Controls;

namespace PakTrack.UI.LightArea
{
    /// <summary>
    /// Interaction logic for LightView
    /// </summary>
    public partial class LightView : UserControl
    {
        public LightView()
        {
            InitializeComponent();
        }
    }
}
