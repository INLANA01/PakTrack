﻿namespace PakTrack.UI.DashboardArea
{
    /// <summary>
    /// Interaction logic for DashboardView
    /// </summary>
    public partial class DashboardView
    {
        public DashboardView()
        {
            InitializeComponent();
        }
    }
}
