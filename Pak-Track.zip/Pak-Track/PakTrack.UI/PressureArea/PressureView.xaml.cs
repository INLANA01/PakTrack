﻿using System.Windows.Controls;

namespace PakTrack.UI.PressureArea
{
    /// <summary>
    /// Interaction logic for PressureView
    /// </summary>
    public partial class PressureView : UserControl
    {
        public PressureView()
        {
            InitializeComponent();
        }
    }
}
