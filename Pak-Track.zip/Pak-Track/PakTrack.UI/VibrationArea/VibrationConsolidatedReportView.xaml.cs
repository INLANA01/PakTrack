﻿using System.Windows.Controls;

namespace PakTrack.UI.VibrationArea
{
    /// <summary>
    /// Interaction logic for VibrationConsolidatedReportView
    /// </summary>
    public partial class VibrationConsolidatedReportView
    {
        public VibrationConsolidatedReportView()
        {
            InitializeComponent();
        }
    }
}
