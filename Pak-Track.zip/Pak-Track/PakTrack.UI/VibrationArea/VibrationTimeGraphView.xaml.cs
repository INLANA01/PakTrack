﻿using System.Windows.Controls;

namespace PakTrack.UI.VibrationArea
{
    /// <summary>
    /// Interaction logic for VibrationTimeGraphView
    /// </summary>
    public partial class VibrationTimeGraphView
    {
        public VibrationTimeGraphView()
        {
            InitializeComponent();
        }
    }
}
