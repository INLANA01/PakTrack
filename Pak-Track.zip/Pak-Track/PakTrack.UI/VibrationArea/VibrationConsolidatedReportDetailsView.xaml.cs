﻿using System.Windows.Controls;

namespace PakTrack.UI.VibrationArea
{
    /// <summary>
    /// Interaction logic for VibrationConsolidatedReportDetailsView
    /// </summary>
    public partial class VibrationConsolidatedReportDetailsView : UserControl
    {
        public VibrationConsolidatedReportDetailsView()
        {
            InitializeComponent();
        }
    }
}
