﻿using System.Windows.Controls;

namespace PakTrack.UI.VibrationArea
{
    /// <summary>
    /// Interaction logic for VibrationPSDGraphView
    /// </summary>
    public partial class VibrationPSDGraphView : UserControl
    {
        public VibrationPSDGraphView()
        {
            InitializeComponent();
        }
    }
}
