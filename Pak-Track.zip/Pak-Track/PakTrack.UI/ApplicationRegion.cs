﻿namespace PakTrack.UI
{
    public class ApplicationRegion
    {
        public const string MainRegion = "ContentRegion";
        public const string SideBarMenu = "SideBarMenu";
        public const string HeaderMenu = "HeaderMenu";
    }
}