﻿namespace PakTrack.Models
{
    public class PressureSensorConfiguration : SensorConfigurationBase { }
}