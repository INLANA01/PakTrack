﻿namespace PakTrack.Models
{
    public class VibrationSensorConfiguration : SensorConfigurationBase { }
}