﻿namespace PakTrack.Models
{
    public class LightSensorConfiguration : SensorConfigurationBase { }
}