﻿namespace PakTrack.Models
{
    public class TemperatureSensorConfiguration : SensorConfigurationBase { }
}