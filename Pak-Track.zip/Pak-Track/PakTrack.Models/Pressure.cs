﻿namespace PakTrack.Models
{
    /// <summary>
    /// Class to represent a pressure event
    /// </summary>
    public class Pressure : SimpleValueEvent
    {
    }
}