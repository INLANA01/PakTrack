﻿namespace PakTrack.Models
{
    /// <summary>
    /// Class to represent a temperature event
    /// </summary>
    public class Temperature : SimpleValueEvent
    {
    }
}