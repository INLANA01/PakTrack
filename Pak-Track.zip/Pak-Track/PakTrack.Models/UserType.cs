﻿namespace PakTrack.Models
{
    public enum UserType
    {
        GeneralUser,
        Administrator
    }
}