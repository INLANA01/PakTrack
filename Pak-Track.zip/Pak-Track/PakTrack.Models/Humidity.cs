﻿namespace PakTrack.Models
{
    /// <summary>
    /// Class to represent a humidity event
    /// </summary>
    public class Humidity : SimpleValueEvent
    {
    }
}