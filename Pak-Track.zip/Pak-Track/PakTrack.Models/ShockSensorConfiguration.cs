﻿namespace PakTrack.Models
{
    public class ShockSensorConfiguration : SensorConfigurationBase { }
}