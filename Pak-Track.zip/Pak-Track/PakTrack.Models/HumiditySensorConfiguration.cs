﻿namespace PakTrack.Models
{
    public class HumiditySensorConfiguration : SensorConfigurationBase { }
}